<?php
 $a = 5;
 if ($a = 1) {
     var_dump($a);
 } elseif ($b = 2) {}
 while ($c = 3) {}
 for (;$d = 4;) {}
